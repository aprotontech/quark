#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <opus.h>
#include <unistd.h>
#include <fcntl.h>

#define SAMPLE_RATE 16000  
#define CHANNEL_NUM 1  
#define BIT_RATE 16000  
#define BIT_PER_SAMPLE 16  
#define WB_FRAME_SIZE 320  
#define DATA_SIZE 320 * 2 * 100
  
int encode(char* in, int len, unsigned char* opus, int* opus_len) {  
    int err = 0;  
    opus_int32 skip = 0;  
  
    OpusEncoder *enc = opus_encoder_create(SAMPLE_RATE, CHANNEL_NUM,  
            OPUS_APPLICATION_VOIP, &err);  
    if (err != OPUS_OK) {  
        fprintf(stderr, "cannnot create opus encoder: %s\n",  
                opus_strerror(err));  
        enc = NULL;  
        return -1;  
    }  
  
    opus_encoder_ctl(enc, OPUS_SET_BANDWIDTH(OPUS_BANDWIDTH_WIDEBAND));  
    opus_encoder_ctl(enc, OPUS_SET_BITRATE(BIT_RATE));  
    opus_encoder_ctl(enc, OPUS_SET_VBR(1));  
    opus_encoder_ctl(enc, OPUS_SET_COMPLEXITY(3));  
    opus_encoder_ctl(enc, OPUS_SET_INBAND_FEC(0));  
    opus_encoder_ctl(enc, OPUS_SET_FORCE_CHANNELS(OPUS_AUTO));  
    opus_encoder_ctl(enc, OPUS_SET_SIGNAL(OPUS_SIGNAL_VOICE));  
    opus_encoder_ctl(enc, OPUS_SET_DTX(0));  
    opus_encoder_ctl(enc, OPUS_SET_PACKET_LOSS_PERC(0));  
    opus_encoder_ctl(enc, OPUS_SET_LSB_DEPTH(16));  
  
    short frame_size = WB_FRAME_SIZE;  
    int frame_bytes = (frame_size << 1);  
  
    opus_int16 *frame = (opus_int16 *) in;  
    unsigned char *cbits = opus;  
  
    while (len > frame_bytes) {  
        int nbytes = opus_encode(enc, frame, frame_size, cbits + sizeof(char),  
                640 - sizeof(short));  
        if (nbytes > frame_size * 2 || nbytes < 0) {  
            return -1;  
        }  
        cbits[0] = nbytes;  
        frame += WB_FRAME_SIZE;  
        cbits += nbytes + sizeof(char);  
        len -= frame_bytes;  
        *opus_len += nbytes + sizeof(char);  
    }  
    opus_encoder_destroy(enc);  
    return 0;  
}

int main() {
	char* src_data = (char*)malloc(DATA_SIZE);
	// 打开文件
    int in_fd = open("./iattest.wav", O_RDONLY);
    if (in_fd == -1) 
    {   
        printf("open fail\n");
        return;
    }   

    // 读取音频
    int len = read(in_fd, src_data, DATA_SIZE);
    if (len < DATA_SIZE) {   
        printf("read fail\n");
        return;
    }

	unsigned char* out_data = (unsigned char*)malloc(DATA_SIZE);
	memset(out_data, 0, DATA_SIZE);

	int out_len = -1;
	int res = encode(src_data, DATA_SIZE, out_data, &out_len);
	printf("res = %d, out_len = %d\n", res, out_len);
	
	return 0;
}
